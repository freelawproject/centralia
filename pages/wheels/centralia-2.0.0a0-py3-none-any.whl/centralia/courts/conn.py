"""Supreme Court of Connecticut ('conn').

Everything unique to conn lives here. It imports core, never another court
file, and no other court file imports it. Its CourtProfile is registered in
courts/__init__.py (with `front_matter=('syllabus',)`, which is what builds
the syllabus SECTION — this reader must not claim those rows).

THE CONTRACT — Connecticut publishes the REPORTER'S advance release, and it
reads like a page of the bound volume rather than like a slip. Page 1 is
nothing but the Reporter's notice; the paper starts on page 2 under a running
head fenced by two rules.

    ┌─ page 1 ───────────────────────────────────────────────────────────┐
    │      ****************************************************           │
    │      The "officially released" date that appears near the …          │  the notice,
    │      All opinions are subject to modification and technical …       │  the whole
    │      … the latest version is to be considered authoritative.        │  page
    └────────────────────────────────────────────────────────────────────┘
    ┌─ page 2 ───────────────────────────────────────────────────────────┐
    ├──────────────────────── rule ──────────────────────────────────────┤
    │                       State v. Bard             8pt running head   │
    ├──────────────────────── rule ──────────────────────────────────────┤
    │          STATE OF CONNECTICUT v. KEVIN BARD     11pt — the caption │
    │                       (SC 21016)                11pt — the docket  │
    │        Mullins, C. J., and McDonald, D'Auria, Ecker,               │
    │            Alexander, Dannehy and Bright, Js.    8pt — the panel   │
    │                        Syllabus                  8pt — the         │
    │ The defendant was charged with … (8pt)                Reporter's   │
    │                                                                    │
    │      Argued March 5—officially released May 5, 2026   the dates    │
    │                    Procedural History                              │
    │     Substitute information charging the defendant with … (11pt)    │
    └────────────────────────────────────────────────────────────────────┘

THE TYPE SAYS WHOSE WORDS THEY ARE. The court's own text — the caption, the
docket, the opinion — is 11pt; everything the REPORTER adds around it is 8pt:
the running head, the panel roster, the syllabus and its heading, the
argued/released line, the 'Procedural History' heading and the footnotes.
That one measurement is the whole parser, and it is why nothing here is keyed
to a page number or a row index.

THE SYLLABUS IS NOT CLAIMED. `front_matter=('syllabus',)` already gives conn
a syllabus section, and it is a long one — claiming those rows into the
headmatter would move the Reporter's précis out of the section built for it
and into the block. So the walk STOPS at the 'Syllabus' heading and then
looks only for the argued/released line that stands below it, which is the
one piece of the block the Reporter prints after the précis.

THE NOTICE NAMES ITSELF. It opens with a rule of asterisks and every line of
it stands in the Reporter's measure (x0 174-186) on page 1 alone. It is
dropped, not tinted: none of it is the court's writing, and it is printed
identically on all 50 records.
"""

from __future__ import annotations

import re

from .. import model as m
from ..resolve.evidence import NOTHING, decider
from ..resolve.footnotes import line_markup
from ..resolve.furniture import FurnitureFinder

_MAX_PAGES = 6
_AXIS_TOL = 30.0        # the Reporter's measure is narrow and centred
# The court's own type against the Reporter's. Measured over 50 records:
# 11pt for the court, 8pt for everything the Reporter adds, 10pt for the
# asterisk rule that opens the notice.
_COURT_SIZE_MIN = 10.5

_ASTERISKS = re.compile(r"^\*{6,}$")
_NOTICE_WORDS = re.compile(
    r"officially released|subject to modification|Connecticut Law Journal"
    r"|advance release version|considered authoritative"
    r"|Connecticut Reports|Connecticut Appellate Reports", re.I)
# '(SC 21016)' / '(AC 46012)' / '(SC 21016, SC 21017)'
_DOCKET = re.compile(r"^\((?:SC|AC)\s*\d+[\s,;]*(?:(?:SC|AC)?\s*\d+)*\)$", re.I)
# The panel roster: a list of names closing in 'Js.' or 'J.'
_ROSTER = re.compile(r"\bJs?\.\s*$")
_SYLLABUS_HEAD = re.compile(r"^Syllabus$", re.I)
# 'Argued March 5—officially released May 5, 2026'
_ARGUED_RELEASED = re.compile(
    r"^(?:Argued|Submitted)\s+(.+?)[—–-]\s*officially released\s+(.+)$", re.I)
_RELEASED_ONLY = re.compile(r"^officially released\s+(.+)$", re.I)
_PIVOT = re.compile(r"\sv\.\s", re.I)


def _norm(text: str) -> str:
    return " ".join(text.split())


@decider("headmatter.read", court="conn")
def read_headmatter_conn(model, geom, **_):
    """Read Connecticut's advance release block, or NOTHING."""
    if len(model.pages) < 2:
        return NOTHING
    body_size = (geom.body_size if geom and geom.body_size else 11.0)
    body_x0 = (geom.body_x0 if geom and geom.body_x0 else 174.0)
    finder = FurnitureFinder(model, body_x0, body_size)

    ctx = _Ctx()
    # ---- page 1: the Reporter's notice, whole ---------------------------
    for group in _rows(model.pages[0], finder):
        text = _norm(" ".join(l.plain for l in group))
        if not text:
            continue
        if _ASTERISKS.match(text) or _NOTICE_WORDS.search(text) \
                or ctx.dropped:
            ctx.drop(group, "notice")
    if not ctx.dropped:
        return NOTHING          # no notice page: not this paper

    # ---- the paper's own opening -----------------------------------------
    # THE CAPTION is the first row the COURT sets — 11pt, centred, carrying
    # the pivot — anywhere in the pages after the notice. Found by landmark,
    # never by page: a consolidated record runs the notice onto a second
    # page.
    caption_pm = caption_idx = None
    for pm in model.pages[1:_MAX_PAGES]:
        rows = _rows(pm, finder)
        for idx, group in enumerate(rows):
            text = _norm(" ".join(l.plain for l in group))
            if (group[0].size or 0.0) >= _COURT_SIZE_MIN and _PIVOT.search(text) \
                    and text == text.upper():
                caption_pm, caption_idx = pm, idx
                break
            if _DOCKET.match(text):
                caption_pm, caption_idx = pm, max(0, idx - 1)
                break
        if caption_pm is not None:
            break
    if caption_pm is None:
        return NOTHING

    caption: list[str] = []
    stopped = False
    for group in _rows(caption_pm, finder)[caption_idx:]:
        text = _norm(" ".join(l.plain for l in group))
        if not text:
            continue
        if _SYLLABUS_HEAD.match(text):
            # THE REPORTER'S PRECIS HAS ITS OWN SECTION. Stop here.
            stopped = True
            break
        if _DOCKET.match(text):
            ctx.crit.setdefault(
                "docket", [t.strip() for t in
                           text.strip("()").replace(";", ",").split(",")
                           if t.strip()])
            ctx.emit(group, "docket")
            continue
        if _ROSTER.search(text) and (group[0].size or 0.0) < _COURT_SIZE_MIN:
            ctx.crit.setdefault("panel_line", text)
            ctx.emit(group, "panel")
            continue
        if (group[0].size or 0.0) >= _COURT_SIZE_MIN:
            caption.append(text)
            ctx.emit(group, "caption")
            continue
        # A Reporter's row this reader cannot name is left alone.
        continue

    # ---- the argued/released line, below the précis ----------------------
    # It is the one piece of the block the Reporter prints AFTER the
    # syllabus, so it is looked for on its own rather than walked to.
    for pm in model.pages[1:_MAX_PAGES]:
        for group in _rows(pm, finder):
            text = _norm(" ".join(l.plain for l in group))
            both = _ARGUED_RELEASED.match(text)
            if both:
                ctx.crit.setdefault("argued", _norm(both.group(1)))
                ctx.crit.setdefault("decision_date", _norm(both.group(2)))
                ctx.emit(group, "date")
                break
            only = _RELEASED_ONLY.match(text)
            if only:
                ctx.crit.setdefault("decision_date", _norm(only.group(1)))
                ctx.emit(group, "date")
                break
        if ctx.crit.get("decision_date"):
            break

    if not ctx.crit.get("docket") or not stopped:
        return NOTHING
    if caption:
        ctx.crit.setdefault("case_name", " ".join(caption))
        ctx.crit.setdefault("parties", caption[:4])
    return ctx.result()


def _rows(pm, finder) -> list[list]:
    groups: dict = {}
    order: list = []
    for line in sorted(pm.lines, key=lambda l: (l.top, l.x0)):
        if not line.plain.strip() or finder.kind(pm, line):
            continue
        key = round(line.top, 1)
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(line)
    return [groups[k] for k in order]


class _Ctx:
    """The emit buffer: what the walk placed, and where it came from."""

    def __init__(self):
        self.items: list = []
        self.dropped: list = []
        self.consumed: set[int] = set()
        self.crit: dict = {}

    def emit(self, group: list, role: str, centre: bool = True) -> None:
        parts = sorted(group, key=lambda l: l.x0)
        if not parts:
            return
        first = parts[0]
        text = ""
        for part in parts:
            piece = line_markup(part)
            text = (text.rstrip() + " " + piece.lstrip()) if text.strip() \
                else piece
        self.items.append(m.HmLine(
            text=text, prov=m.Prov(first.page, tuple(p.id for p in parts)),
            align=m.Align.CENTER if centre else m.Align.LEFT,
            x0=first.x0, size=first.size or 0.0,
            bold=all(bool(p.all_bold) for p in parts), role=role))
        self.consumed.update(p.id for p in parts)

    def drop(self, group: list, kind: str) -> None:
        parts = sorted(group, key=lambda l: l.x0)
        self.dropped.append(m.Dropped(
            text=_norm(" ".join(p.plain for p in parts))[:400],
            prov=m.Prov(parts[0].page, tuple(p.id for p in parts)),
            kind=kind or "furniture"))
        self.consumed.update(p.id for p in parts)

    def result(self) -> dict:
        return {"criteria": self.crit, "items": self.items, "attorneys": [],
                "dropped": self.dropped, "consumed": self.consumed,
                "anchor_ids": [], "doc_type_final": None}
